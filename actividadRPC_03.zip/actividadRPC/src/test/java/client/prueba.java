package client;

import java.util.Arrays;

public class prueba {
    public static void main(String[] args) {
        int [] numeros = {4, 1, 8, 2, 9};
        Arrays.sort(numeros);
        int [] numOrden = new int[5];
        for (int n : numeros) {
            System.out.println(n);
            for (int i=0; i<numeros.length; i++) {
                numOrden[i]= n;
            }
        }
        for (int n : numOrden){
            System.out.println(n);
        }

    }
}
